import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand, GetCommand, QueryCommand, DeleteCommand } from "@aws-sdk/lib-dynamodb";
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    retryMode: 'adaptive',
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

const WORKSHOPS_TABLE = process.env.WORKSHOPS_TABLE;
const REGISTRATIONS_TABLE = process.env.REGISTRATIONS_TABLE;
const VALID_TICKETS_TABLE = process.env.VALID_TICKETS_TABLE;
const ADMIN_PERMISSIONS_TABLE = process.env.ADMIN_PERMISSIONS_TABLE;
const RATINGS_TABLE = process.env.RATINGS_TABLE;

const getCORSHeaders = (origin) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS;
    
    if (!allowedOrigins || allowedOrigins.trim() === '') {
        console.error('ALLOWED_ORIGINS environment variable is not configured');
        return {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'null',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,GET,DELETE'
        };
    }
    
    const allowedOriginsList = allowedOrigins.split(',').map(origin => origin.trim());
    const allowedOrigin = allowedOriginsList.includes(origin) ? origin : 'null';
    
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,DELETE'
    };
};

async function getAdminPermissions(ticketId) {
    try {
        const permissionsResult = await dynamodb.send(new QueryCommand({
            TableName: ADMIN_PERMISSIONS_TABLE,
            KeyConditionExpression: 'ticketId = :ticketId',
            ExpressionAttributeValues: {
                ':ticketId': ticketId
            },
            ConsistentRead: false
        }));
        
        const permissions = permissionsResult.Items || [];
        
        // Check if user is super admin
        if (permissions.some(p => p.workshopId === '*')) {
            const workshopsResult = await dynamodb.send(new ScanCommand({
                TableName: WORKSHOPS_TABLE,
                ProjectionExpression: 'id',
                ConsistentRead: false
            }));
            return (workshopsResult.Items || []).map(item => item.id);
        }
        
        return permissions.map(item => item.workshopId);
    } catch (error) {
        console.error('Error getting admin permissions:', error);
        return []; // Return empty array on error to deny access
    }
}

async function isAdminForWorkshop(ticketId, workshopId) {
    try {
        // Parallel check for both super admin and specific workshop permissions
        const [superAdminResult, permissionResult] = await Promise.allSettled([
            // Check for super admin permission
            dynamodb.send(new GetCommand({
                TableName: ADMIN_PERMISSIONS_TABLE,
                Key: { ticketId, workshopId: '*' },
                ConsistentRead: false
            })),
            
            // Check for specific workshop permission
            dynamodb.send(new GetCommand({
                TableName: ADMIN_PERMISSIONS_TABLE,
                Key: { ticketId, workshopId },
                ConsistentRead: false
            }))
        ]);
        
        // Check if super admin exists
        if (superAdminResult.status === 'fulfilled' && superAdminResult.value.Item) {
            return true; // Super admin
        }
        
        // Check if specific workshop permission exists
        if (permissionResult.status === 'fulfilled' && permissionResult.value.Item) {
            return true; // Workshop-specific admin
        }
        
        return false;
    } catch (error) {
        console.error('Error checking admin permissions:', error);
        return false; // Deny access on error
    }
}

export const handler = async (event) => {
    const origin = event.headers?.Origin || event.headers?.origin;
    const headers = getCORSHeaders(origin);
        
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: JSON.stringify({ message: 'CORS preflight successful' }) };
        }
        
        // Extract admin ticket ID from authorization header
        const authHeader = event.headers?.Authorization || event.headers?.authorization;
        if (!authHeader) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. Admin authorization required.' }) };
        }
        
        const adminTicketId = authHeader.replace('Bearer ', '').trim();
        
        // Check if this ticket has any admin permissions
        const allowedWorkshops = await getAdminPermissions(adminTicketId);
        if (allowedWorkshops.length === 0) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. Admin privileges required.' }) };
        }

        const { httpMethod, pathParameters, resource } = event;
        
        if (httpMethod === 'GET' && resource === '/admin/registrations') {
            return await getAllRegistrations(allowedWorkshops, headers);
        } else if (httpMethod === 'GET' && resource === '/admin/ratings/{workshopId}') {
            const workshopId = pathParameters?.workshopId;
            return await getWorkshopRatings(adminTicketId, workshopId, headers);
        } else if (httpMethod === 'DELETE' && pathParameters?.ticketId && pathParameters?.workshopId) {
            const registrationTicketId = pathParameters.ticketId;
            const workshopId = pathParameters.workshopId;
            return await adminWithdrawRegistration(adminTicketId, registrationTicketId, workshopId, headers);
        } else {
            console.log('No matching route found');
            return { statusCode: 405, headers, body: JSON.stringify({ 
                error: 'Method not allowed',
                httpMethod,
                resource,
                pathParameters: pathParameters || 'none'
            }) };
        }
        
    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Internal server error' }) };
    }
};

async function getAllRegistrations(allowedWorkshops, headers) {
    try {
        const registrationsResult = await dynamodb.send(new ScanCommand({
            TableName: REGISTRATIONS_TABLE,
            ConsistentRead: false
        }));
        
        const allRegistrations = registrationsResult.Items || [];
        
        const filteredRegistrations = allRegistrations.filter(reg => 
            allowedWorkshops.includes(reg.workshopId)
        );
        
        // Batch process workshop details for better performance
        const BATCH_SIZE = 10;
        const registrationBatches = [];
        
        for (let i = 0; i < filteredRegistrations.length; i += BATCH_SIZE) {
            registrationBatches.push(filteredRegistrations.slice(i, i + BATCH_SIZE));
        }
        
        const registrationsWithDetails = [];
        
        // Process batches to avoid overwhelming DynamoDB
        for (const batch of registrationBatches) {
            const batchResults = await Promise.allSettled(
                batch.map(async (registration) => {
                    try {
                        const workshopResult = await dynamodb.send(new GetCommand({
                            TableName: WORKSHOPS_TABLE,
                            Key: { id: registration.workshopId },
                            ConsistentRead: false
                        }));
                        
                        return {
                            ...registration,
                            workshopTitle: workshopResult.Item ? workshopResult.Item.title : 'Unknown Workshop'
                        };
                    } catch (error) {
                        console.error(`Error getting workshop details for ${registration.workshopId}:`, error);
                        return {
                            ...registration,
                            workshopTitle: 'Unknown Workshop'
                        };
                    }
                })
            );
            
            // Extract successful results
            batchResults.forEach(result => {
                if (result.status === 'fulfilled') {
                    registrationsWithDetails.push(result.value);
                } else {
                    console.error('Batch processing error:', result.reason);
                }
            });
        }
        
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ registrations: registrationsWithDetails })
        };
        
    } catch (error) {
        console.error('Error getting registrations:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to get registrations' }) };
    }
}

async function getWorkshopRatings(adminTicketId, workshopId, headers) {
    if (!workshopId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Workshop ID is required' }) };
    }
    
    try {
        // Parallel execution of permission check and ratings retrieval
        const [hasPermission, ratingsResult] = await Promise.allSettled([
            // Check if admin has permission for this specific workshop
            isAdminForWorkshop(adminTicketId, workshopId),
            
            // Get all ratings for this workshop
            dynamodb.send(new QueryCommand({
                TableName: RATINGS_TABLE,
                IndexName: 'workshopId-index',
                KeyConditionExpression: 'workshopId = :workshopId',
                ExpressionAttributeValues: {
                    ':workshopId': workshopId
                },
                ConsistentRead: false
            }))
        ]);
        
        // Handle permission check
        if (hasPermission.status === 'rejected' || !hasPermission.value) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. You do not have permission to view ratings for this workshop.' }) };
        }
        
        // Handle ratings query
        if (ratingsResult.status === 'rejected') {
            console.error('Error getting workshop ratings:', ratingsResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to get workshop ratings' }) };
        }
        
        const ratings = ratingsResult.value.Items || [];
        
        // Batch process user data enrichment
        const BATCH_SIZE = 10;
        const ratingBatches = [];
        
        for (let i = 0; i < ratings.length; i += BATCH_SIZE) {
            ratingBatches.push(ratings.slice(i, i + BATCH_SIZE));
        }
        
        const ratingsWithUserData = [];
        
        // Process batches to avoid overwhelming DynamoDB
        for (const batch of ratingBatches) {
            const batchResults = await Promise.allSettled(
                batch.map(async (rating) => {
                    try {
                        const userResult = await dynamodb.send(new GetCommand({
                            TableName: VALID_TICKETS_TABLE,
                            Key: { ticketId: rating.ticketId },
                            ConsistentRead: false
                        }));
                        
                        return {
                            ...rating,
                            firstName: userResult.Item?.firstName || 'Anonymous',
                            lastName: userResult.Item?.lastName || ''
                        };
                    } catch (error) {
                        console.error(`Error getting user details for ${rating.ticketId}:`, error);
                        return {
                            ...rating,
                            firstName: 'Anonymous',
                            lastName: ''
                        };
                    }
                })
            );
            
            // Extract successful results
            batchResults.forEach(result => {
                if (result.status === 'fulfilled') {
                    ratingsWithUserData.push(result.value);
                } else {
                    console.error('Batch processing error:', result.reason);
                }
            });
        }
        
        console.log(`Admin ${adminTicketId} accessed ratings for workshop ${workshopId}. Found ${ratings.length} ratings.`);
        
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ 
                success: true,
                ratings: ratingsWithUserData,
                workshopId: workshopId,
                totalRatings: ratings.length
            })
        };
        
    } catch (error) {
        console.error('Error getting workshop ratings:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to get workshop ratings' }) };
    }
}

async function adminWithdrawRegistration(adminTicketId, registrationTicketId, workshopId, headers) {
    if (!registrationTicketId || !workshopId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID and Workshop ID are required' }) };
    }
    
    try {
        // Check if admin has permission for this specific workshop
        const hasPermission = await isAdminForWorkshop(adminTicketId, workshopId);
        if (!hasPermission) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. You do not have permission to manage this workshop.' }) };
        }
        
        const upperTicketId = registrationTicketId.toUpperCase();
        
        // Use conditional delete for atomicity - check existence and delete in one operation
        await dynamodb.send(new DeleteCommand({
            TableName: REGISTRATIONS_TABLE,
            Key: { ticketId: upperTicketId, workshopId: workshopId },
            // Ensure the registration exists before deletion
            ConditionExpression: 'attribute_exists(ticketId) AND attribute_exists(workshopId)',
            ReturnValues: 'ALL_OLD'
        }));
        
        console.log(`Admin ${adminTicketId} withdrew registration for ${upperTicketId} from ${workshopId}`);
        
        return { 
            statusCode: 200, 
            headers, 
            body: JSON.stringify({ message: 'Registration withdrawn successfully by admin' }) 
        };
        
    } catch (error) {
        console.error('Error withdrawing registration:', error);
        
        // Handle conditional check failed error specifically
        if (error.name === 'ConditionalCheckFailedException') {
            return { statusCode: 404, headers, body: JSON.stringify({ error: 'Registration not found' }) };
        }
        
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to withdraw registration' }) };
    }
}