import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

const RATINGS_TABLE = process.env.RATINGS_TABLE;
const WORKSHOPS_TABLE = process.env.WORKSHOPS_TABLE;
const REGISTRATIONS_TABLE = process.env.REGISTRATIONS_TABLE;
const ADMIN_PERMISSIONS_TABLE = process.env.ADMIN_PERMISSIONS_TABLE;

const getCORSHeaders = (origin) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS;
    
    if (!allowedOrigins || allowedOrigins.trim() === '') {
        console.error('ALLOWED_ORIGINS environment variable is not configured');
        return {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'null',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,GET,POST'
        };
    }
    
    const allowedOriginsList = allowedOrigins.split(',').map(origin => origin.trim());
    const allowedOrigin = allowedOriginsList.includes(origin) ? origin : 'null';
    
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE',
        'Access-Control-Allow-Credentials': 'false'
    };
};

async function isAdminForWorkshop(ticketId, workshopId) {
    try {
        // Parallel check for both super admin and specific workshop permissions
        const [superAdminResult, permissionResult] = await Promise.allSettled([
            // Check for super admin permission
            dynamodb.send(new GetCommand({
                TableName: ADMIN_PERMISSIONS_TABLE,
                Key: { ticketId, workshopId: '*' },
                ConsistentRead: false
            })),
            
            // Check for specific workshop permission
            dynamodb.send(new GetCommand({
                TableName: ADMIN_PERMISSIONS_TABLE,
                Key: { ticketId, workshopId },
                ConsistentRead: false
            }))
        ]);
        
        // Check if super admin exists
        if (superAdminResult.status === 'fulfilled' && superAdminResult.value.Item) {
            return true; // Super admin
        }
        
        // Check if specific workshop permission exists
        if (permissionResult.status === 'fulfilled' && permissionResult.value.Item) {
            return true; // Workshop-specific admin
        }
        
        return false;
    } catch (error) {
        console.error('Error checking admin permissions:', error);
        return false; // Deny access on error
    }
}

export const handler = async (event) => {
    const origin = event.headers?.Origin || event.headers?.origin;
    const headers = getCORSHeaders(origin);
    
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: JSON.stringify({ message: 'CORS preflight successful' }) };
        }
        
        const { httpMethod, pathParameters, resource } = event;
        
        if (httpMethod === 'POST' && resource === '/ratings') {
            return await submitRating(event, headers);
        } else if (httpMethod === 'GET' && resource === '/ratings/{ticketId}') {
            return await getUserRatings(pathParameters?.ticketId, headers);
        } else if (httpMethod === 'GET' && resource === '/admin/ratings/{workshopId}') {
            return await getWorkshopRatings(pathParameters?.workshopId, event, headers);
        } else {
            return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
        }
        
    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Internal server error' }) };
    }
};

async function submitRating(event, headers) {
    const { 
        ticketId, 
        workshopId, 
        contentSatisfaction, 
        speakerEffectiveness, 
        learnedSomething, 
        additionalFeedback 
    } = JSON.parse(event.body || '{}');
    
    if (!ticketId || !workshopId || !contentSatisfaction || !speakerEffectiveness || !learnedSomething) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'All required fields must be provided' }) };
    }
    
    if (contentSatisfaction < 1 || contentSatisfaction > 5 || speakerEffectiveness < 1 || speakerEffectiveness > 5) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Rating values must be between 1 and 5' }) };
    }
    
    if (!['Yes', 'No'].includes(learnedSomething)) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'learnedSomething must be Yes or No' }) };
    }
    
    const upperTicketId = ticketId.toUpperCase();
    
    try {
        // Parallel validation for registration and existing rating
        const [registrationResult, existingRatingResult] = await Promise.allSettled([
            // Verify user was registered for this workshop
            dynamodb.send(new GetCommand({
                TableName: REGISTRATIONS_TABLE,
                Key: { ticketId: upperTicketId, workshopId: workshopId },
                ConsistentRead: false
            })),
            
            // Check if user has already rated this workshop
            dynamodb.send(new GetCommand({
                TableName: RATINGS_TABLE,
                Key: { ticketId: upperTicketId, workshopId: workshopId },
                ConsistentRead: false
            }))
        ]);
        
        // Handle registration validation
        if (registrationResult.status === 'rejected') {
            console.error('Error validating registration:', registrationResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to validate registration' }) };
        }
        
        if (!registrationResult.value.Item) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'You must be registered for this workshop to rate it' }) };
        }
        
        // Handle existing rating validation
        if (existingRatingResult.status === 'rejected') {
            console.error('Error checking existing rating:', existingRatingResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to check existing rating' }) };
        }
        
        if (existingRatingResult.value.Item) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'You have already rated this workshop' }) };
        }
        
        // Get user details from registration
        const registration = registrationResult.value.Item;
        
        // Store the rating with conditional expression to prevent duplicates
        const ratingItem = {
            ticketId: upperTicketId,
            workshopId: workshopId,
            contentSatisfaction: contentSatisfaction,
            speakerEffectiveness: speakerEffectiveness,
            learnedSomething: learnedSomething,
            additionalFeedback: additionalFeedback || '',
            firstName: registration.firstName,
            lastName: registration.lastName,
            submittedAt: new Date().toISOString()
        };
        
        await dynamodb.send(new PutCommand({
            TableName: RATINGS_TABLE,
            Item: ratingItem,
            // Prevent duplicate ratings at the database level
            ConditionExpression: 'attribute_not_exists(ticketId) AND attribute_not_exists(workshopId)'
        }));
        
        return { statusCode: 200, headers, body: JSON.stringify({ message: 'Rating submitted successfully' }) };
        
    } catch (error) {
        console.error('Error during rating submission:', error);
        
        // Handle conditional check failed error specifically
        if (error.name === 'ConditionalCheckFailedException') {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'You have already rated this workshop' }) };
        }
        
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to submit rating' }) };
    }
}

async function getUserRatings(ticketId, headers) {
    if (!ticketId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID is required' }) };
    }
    
    try {
        const result = await dynamodb.send(new QueryCommand({
            TableName: RATINGS_TABLE,
            KeyConditionExpression: 'ticketId = :ticketId',
            ExpressionAttributeValues: { ':ticketId': ticketId.toUpperCase() },
            ConsistentRead: false // Use eventually consistent reads for better performance
        }));
        
        return { statusCode: 200, headers, body: JSON.stringify({ ratings: result.Items || [] }) };
    } catch (error) {
        console.error('Error getting user ratings:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to retrieve ratings' }) };
    }
}

async function getWorkshopRatings(workshopId, event, headers) {
    if (!workshopId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Workshop ID is required' }) };
    }
    
    // Extract admin ticket ID from authorization header
    const authHeader = event.headers?.Authorization || event.headers?.authorization;
    if (!authHeader) {
        return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. Admin authorization required.' }) };
    }
    
    // Extract ticket ID from Bearer token format
    const ticketId = authHeader.replace('Bearer ', '').trim();
    
    try {
        // Check admin permissions and get ratings in parallel
        const [hasPermission, ratingsResult] = await Promise.allSettled([
            // Check if admin has permission for this specific workshop
            isAdminForWorkshop(ticketId, workshopId),
            
            // Get all ratings for this workshop
            dynamodb.send(new QueryCommand({
                TableName: RATINGS_TABLE,
                IndexName: 'workshopId-index',
                KeyConditionExpression: 'workshopId = :workshopId',
                ExpressionAttributeValues: { ':workshopId': workshopId },
                ConsistentRead: false // Use eventually consistent reads
            }))
        ]);
        
        // Handle permission check
        if (hasPermission.status === 'rejected' || !hasPermission.value) {
            return { statusCode: 403, headers, body: JSON.stringify({ error: 'Access denied. You do not have permission to view ratings for this workshop.' }) };
        }
        
        // Handle ratings query
        if (ratingsResult.status === 'rejected') {
            console.error('Error getting workshop ratings:', ratingsResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to retrieve workshop ratings' }) };
        }
        
        const ratings = ratingsResult.value.Items || [];
        
        // Calculate averages with optimized computation
        if (ratings.length > 0) {
            let contentSum = 0;
            let speakerSum = 0;
            let learnedYesCount = 0;
            
            // Single pass calculation for better performance
            for (const rating of ratings) {
                contentSum += rating.contentSatisfaction;
                speakerSum += rating.speakerEffectiveness;
                if (rating.learnedSomething === 'Yes') {
                    learnedYesCount++;
                }
            }
            
            const avgContentSatisfaction = contentSum / ratings.length;
            const avgSpeakerEffectiveness = speakerSum / ratings.length;
            const learnedSomethingPercentage = (learnedYesCount / ratings.length) * 100;
            
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    ratings: ratings,
                    summary: {
                        totalRatings: ratings.length,
                        avgContentSatisfaction: Math.round(avgContentSatisfaction * 10) / 10,
                        avgSpeakerEffectiveness: Math.round(avgSpeakerEffectiveness * 10) / 10,
                        learnedSomethingPercentage: Math.round(learnedSomethingPercentage)
                    }
                })
            };
        } else {
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    ratings: [],
                    summary: {
                        totalRatings: 0,
                        avgContentSatisfaction: 0,
                        avgSpeakerEffectiveness: 0,
                        learnedSomethingPercentage: 0
                    }
                })
            };
        }
        
    } catch (error) {
        console.error('Error in getWorkshopRatings:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to retrieve workshop ratings' }) };
    }
}