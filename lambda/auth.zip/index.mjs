import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

const VALID_TICKETS_TABLE = process.env.VALID_TICKETS_TABLE;
const ADMIN_PERMISSIONS_TABLE = process.env.ADMIN_PERMISSIONS_TABLE;

const getCORSHeaders = (origin) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS;
    
    if (!allowedOrigins || allowedOrigins.trim() === '') {
        console.error('ALLOWED_ORIGINS environment variable is not configured');
        return {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'null',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
        };
    }
    
    const allowedOriginsList = allowedOrigins.split(',').map(origin => origin.trim());
    const allowedOrigin = allowedOriginsList.includes(origin) ? origin : 'null';
    
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE'
    };
};

export const handler = async (event) => {
    const origin = event.headers?.Origin || event.headers?.origin;
    const headers = getCORSHeaders(origin);
    
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: JSON.stringify({ message: 'CORS preflight successful' }) };
        }
        
        if (event.httpMethod !== 'POST') {
            return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
        }
        
        const { ticketId } = JSON.parse(event.body || '{}');
        
        if (!ticketId) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID is required' }) };
        }
        
        const upperTicketId = ticketId.toUpperCase();
        
        try {
            // Parallel execution of ticket validation and admin permissions check
            const [ticketResult, permissionsResult] = await Promise.allSettled([
                // Validate ticket
                dynamodb.send(new GetCommand({
                    TableName: VALID_TICKETS_TABLE,
                    Key: { ticketId: upperTicketId },
                    ConsistentRead: false // Use eventually consistent reads for better performance
                })),
                
                // Check admin permissions
                dynamodb.send(new QueryCommand({
                    TableName: ADMIN_PERMISSIONS_TABLE,
                    KeyConditionExpression: 'ticketId = :ticketId',
                    ExpressionAttributeValues: {
                        ':ticketId': upperTicketId
                    },
                    ConsistentRead: false // Use eventually consistent reads
                }))
            ]);
            
            // Handle ticket validation
            if (ticketResult.status === 'rejected') {
                console.error('Error validating ticket:', ticketResult.reason);
                return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to validate ticket' }) };
            }
            
            if (!ticketResult.value.Item || !ticketResult.value.Item.isValid) {
                return { statusCode: 401, headers, body: JSON.stringify({ success: false, error: 'Invalid ticket ID' }) };
            }
            
            const ticket = ticketResult.value.Item;
            
            // Handle admin permissions (graceful degradation if this fails)
            let isAdmin = false;
            let adminWorkshops = [];
            
            if (permissionsResult.status === 'fulfilled' && permissionsResult.value.Items && permissionsResult.value.Items.length > 0) {
                isAdmin = true;
                adminWorkshops = permissionsResult.value.Items.map(item => item.workshopId);
                
                // If admin has '*' permission, they're a super admin
                if (adminWorkshops.includes('*')) {
                    adminWorkshops = ['*']; // Super admin has access to all workshops
                }
            } else if (permissionsResult.status === 'rejected') {
                console.error('Error checking admin permissions:', permissionsResult.reason);
                // Continue without admin permissions - graceful degradation
            }
            
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    user: {
                        ticketId: ticket.ticketId,
                        firstName: ticket.firstName,
                        lastName: ticket.lastName,
                        isAdmin: isAdmin,
                        adminWorkshops: adminWorkshops
                    }
                })
            };
            
        } catch (error) {
            console.error('Error during authentication process:', error);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Authentication failed' }) };
        }
        
    } catch (error) {
        console.error('Error in auth handler:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Internal server error' }) };
    }
};