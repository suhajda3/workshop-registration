import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { Agent } from "https"; 

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

const WORKSHOPS_TABLE = process.env.WORKSHOPS_TABLE;
const REGISTRATIONS_TABLE = process.env.REGISTRATIONS_TABLE;

const getCORSHeaders = (origin) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS;
    
    if (!allowedOrigins || allowedOrigins.trim() === '') {
        console.error('ALLOWED_ORIGINS environment variable is not configured');
        return {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'null',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,GET'
        };
    }
    
    const allowedOriginsList = allowedOrigins.split(',').map(origin => origin.trim());
    const allowedOrigin = allowedOriginsList.includes(origin) ? origin : 'null';
    
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE'
    };
};

export const handler = async (event) => {
    const origin = event.headers?.Origin || event.headers?.origin;
    const headers = getCORSHeaders(origin);
    
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { 
                statusCode: 200, 
                headers, 
                body: JSON.stringify({ message: 'CORS preflight successful' }) 
            };
        }
        
        if (event.httpMethod === 'GET') {
            return await getWorkshops(headers);
        } else {
            return { 
                statusCode: 405, 
                headers, 
                body: JSON.stringify({ error: 'Method not allowed' }) 
            };
        }
        
    } catch (error) {
        console.error('Error in workshops function:', error);
        return { 
            statusCode: 500, 
            headers, 
            body: JSON.stringify({ error: 'Internal server error' }) 
        };
    }
};

async function getWorkshops(headers) {
    try {
        // Get all workshops
        const workshopsResult = await dynamodb.send(new ScanCommand({
            TableName: WORKSHOPS_TABLE,
            ConsistentRead: false
        }));
        
        const workshops = workshopsResult.Items || [];
        
        // Get registration counts for each workshop
        const workshopsWithCounts = await Promise.all(
            workshops.map(async (workshop) => {
                try {
                    const registrationCountResult = await dynamodb.send(new QueryCommand({
                        TableName: REGISTRATIONS_TABLE,
                        IndexName: 'workshopId-index',
                        KeyConditionExpression: 'workshopId = :workshopId',
                        ExpressionAttributeValues: { ':workshopId': workshop.id },
                        Select: 'COUNT',
                        ConsistentRead: false
                    }));
                    
                    let speakers = workshop.speakers;
                    if (speakers instanceof Set) {
                        speakers = Array.from(speakers);
                    } else if (!Array.isArray(speakers)) {
                        if (typeof speakers === 'string') {
                            speakers = speakers.split(',').map(s => s.trim());
                        } else if (speakers) {
                            speakers = [String(speakers)];
                        } else {
                            speakers = [];
                        }
                    }
                    
                    return {
                        ...workshop,
                        speakers,
                        currentRegistrations: registrationCountResult.Count || 0,
                        availableSpots: workshop.maxCapacity - (registrationCountResult.Count || 0)
                    };
                } catch (error) {
                    console.error(`Error getting registration count for workshop ${workshop.id}:`, error);
                    
                    let speakers = workshop.speakers;
                    if (speakers instanceof Set) {
                        speakers = Array.from(speakers);
                    } else if (!Array.isArray(speakers)) {
                        if (typeof speakers === 'string') {
                            speakers = speakers.split(',').map(s => s.trim());
                        } else if (speakers) {
                            speakers = [String(speakers)];
                        } else {
                            speakers = [];
                        }
                    }
                    
                    return {
                        ...workshop,
                        speakers,
                        currentRegistrations: 0,
                        availableSpots: workshop.maxCapacity
                    };
                }
            })
        );

        const parseStartMinutes = (timeStr) => {
            if (!timeStr || typeof timeStr !== 'string') return Number.POSITIVE_INFINITY;

            const match = timeStr.match(/(\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)?)/);
            if (!match) return Number.POSITIVE_INFINITY;

            let t = match[1].trim();
            const ampmMatch = t.match(/([APMapm]{2})$/);
            const hasAMPM = Boolean(ampmMatch);
            const numericPart = t.replace(/([APMapm]{2})$/i, '').trim();
            const [hourStr, minuteStr] = numericPart.split(':');

            let hours = parseInt(hourStr, 10);
            const minutes = parseInt(minuteStr, 10);
            if (Number.isNaN(hours) || Number.isNaN(minutes)) return Number.POSITIVE_INFINITY;

            if (hasAMPM) {
                const ampm = ampmMatch[1].toLowerCase();
                if (ampm === 'pm' && hours !== 12) hours += 12;
                if (ampm === 'am' && hours === 12) hours = 0;
            }

            return hours * 60 + minutes;
        };

        workshopsWithCounts.sort((a, b) => {
            const aMin = parseStartMinutes(a.time);
            const bMin = parseStartMinutes(b.time);

            if (aMin === bMin) return 0;
            if (aMin === Number.POSITIVE_INFINITY) return 1;
            if (bMin === Number.POSITIVE_INFINITY) return -1;
            return aMin - bMin;
        });
        
        return { 
            statusCode: 200, 
            headers, 
            body: JSON.stringify({ workshops: workshopsWithCounts }) 
        };
        
    } catch (error) {
        console.error('Error getting workshops:', error);
        return { 
            statusCode: 500, 
            headers, 
            body: JSON.stringify({ error: 'Failed to retrieve workshops' }) 
        };
    }
}