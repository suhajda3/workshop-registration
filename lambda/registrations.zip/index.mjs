import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, GetCommand, PutCommand, DeleteCommand, QueryCommand } from "@aws-sdk/lib-dynamodb";
import { Agent } from "https";

// Create HTTP agent with connection pooling
const httpAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 30000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000,
    freeSocketTimeout: 30000,
    scheduling: 'lifo'
});

// Create clients outside the handler for connection reuse
const client = new DynamoDBClient({
    maxAttempts: 3,
    requestTimeout: 30000,
    httpAgent
});

const dynamodb = DynamoDBDocumentClient.from(client, {
    // Document client configuration for better performance
    marshallOptions: {
        convertEmptyValues: false,
        removeUndefinedValues: true,
        convertClassInstanceToMap: false
    },
    unmarshallOptions: {
        wrapNumbers: false
    }
});

const WORKSHOPS_TABLE = process.env.WORKSHOPS_TABLE;
const REGISTRATIONS_TABLE = process.env.REGISTRATIONS_TABLE;
const VALID_TICKETS_TABLE = process.env.VALID_TICKETS_TABLE;

const getCORSHeaders = (origin) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS;
    
    if (!allowedOrigins || allowedOrigins.trim() === '') {
        console.error('ALLOWED_ORIGINS environment variable is not configured');
        return {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'null',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE'
        };
    }
    
    const allowedOriginsList = allowedOrigins.split(',').map(origin => origin.trim());
    const allowedOrigin = allowedOriginsList.includes(origin) ? origin : 'null';
    
    return {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': allowedOrigin,
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'OPTIONS,GET,POST,DELETE',
        'Access-Control-Allow-Credentials': 'false'
    };
};

export const handler = async (event) => {
    const origin = event.headers?.Origin || event.headers?.origin;
    const headers = getCORSHeaders(origin);
    
    try {
        if (event.httpMethod === 'OPTIONS') {
            return { statusCode: 200, headers, body: JSON.stringify({ message: 'CORS preflight successful' }) };
        }
        
        const { httpMethod, pathParameters } = event;
        
        if (httpMethod === 'GET') {
            const ticketId = pathParameters?.ticketId;
            return await getUserRegistrations(ticketId, headers);
        } else if (httpMethod === 'POST') {
            return await registerForWorkshop(event, headers);
        } else if (httpMethod === 'DELETE') {
            const ticketId = pathParameters?.ticketId;
            const workshopId = pathParameters?.workshopId;
            return await withdrawRegistration(ticketId, workshopId, headers);
        } else {
            return { statusCode: 405, headers, body: JSON.stringify({ error: 'Method not allowed' }) };
        }
        
    } catch (error) {
        console.error('Error:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Internal server error' }) };
    }
};

async function getUserRegistrations(ticketId, headers) {
    if (!ticketId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID is required' }) };
    }
    
    try {
        const result = await dynamodb.send(new QueryCommand({
            TableName: REGISTRATIONS_TABLE,
            KeyConditionExpression: 'ticketId = :ticketId',
            ExpressionAttributeValues: {
                ':ticketId': ticketId.toUpperCase()
            },
            ConsistentRead: false // Use eventually consistent reads for better performance
        }));
        
        return { statusCode: 200, headers, body: JSON.stringify({ registrations: result.Items || [] }) };
    } catch (error) {
        console.error('Error getting user registrations:', error);
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to retrieve registrations' }) };
    }
}

async function registerForWorkshop(event, headers) {
    const { ticketId, workshopId } = JSON.parse(event.body || '{}');
    
    if (!ticketId || !workshopId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID and Workshop ID are required' }) };
    }
    
    const upperTicketId = ticketId.toUpperCase();
    
    try {
        // Parallel validation requests for better performance
        const [ticketResult, workshopResult, existingRegistrationResult] = await Promise.allSettled([
            // Verify ticket is valid
            dynamodb.send(new GetCommand({
                TableName: VALID_TICKETS_TABLE,
                Key: { ticketId: upperTicketId },
                ConsistentRead: false
            })),
            
            // Check if workshop exists
            dynamodb.send(new GetCommand({
                TableName: WORKSHOPS_TABLE,
                Key: { id: workshopId },
                ConsistentRead: false
            })),
            
            // Check if already registered
            dynamodb.send(new GetCommand({
                TableName: REGISTRATIONS_TABLE,
                Key: { ticketId: upperTicketId, workshopId: workshopId },
                ConsistentRead: false
            }))
        ]);
        
        // Handle ticket validation
        if (ticketResult.status === 'rejected') {
            console.error('Error validating ticket:', ticketResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to validate ticket' }) };
        }
        
        if (!ticketResult.value.Item || !ticketResult.value.Item.isValid) {
            return { statusCode: 401, headers, body: JSON.stringify({ error: 'Invalid ticket ID' }) };
        }
        
        // Handle workshop validation
        if (workshopResult.status === 'rejected') {
            console.error('Error validating workshop:', workshopResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to validate workshop' }) };
        }
        
        if (!workshopResult.value.Item) {
            return { statusCode: 404, headers, body: JSON.stringify({ error: 'Workshop not found' }) };
        }
        
        // Handle existing registration check
        if (existingRegistrationResult.status === 'rejected') {
            console.error('Error checking existing registration:', existingRegistrationResult.reason);
            return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to check existing registration' }) };
        }
        
        if (existingRegistrationResult.value.Item) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Already registered for this workshop' }) };
        }
        
        const workshop = workshopResult.value.Item;
        const ticket = ticketResult.value.Item;
        
        // Check workshop capacity
        const registrationCountResult = await dynamodb.send(new QueryCommand({
            TableName: REGISTRATIONS_TABLE,
            IndexName: 'workshopId-index',
            KeyConditionExpression: 'workshopId = :workshopId',
            ExpressionAttributeValues: { ':workshopId': workshopId },
            Select: 'COUNT',
            ConsistentRead: false // Use eventually consistent reads
        }));
        
        if (registrationCountResult.Count >= workshop.maxCapacity) {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Workshop is full' }) };
        }
        
        // Register user with conditional expression to prevent race conditions
        await dynamodb.send(new PutCommand({
            TableName: REGISTRATIONS_TABLE,
            Item: {
                ticketId: upperTicketId,
                workshopId: workshopId,
                firstName: ticket.firstName,
                lastName: ticket.lastName,
                registrationTime: new Date().toISOString(),
                status: 'active'
            },
            // Prevent duplicate registrations at the database level
            ConditionExpression: 'attribute_not_exists(ticketId) AND attribute_not_exists(workshopId)'
        }));
        
        return { statusCode: 200, headers, body: JSON.stringify({ message: 'Registration successful' }) };
        
    } catch (error) {
        console.error('Error during registration:', error);
        
        // Handle conditional check failed error specifically
        if (error.name === 'ConditionalCheckFailedException') {
            return { statusCode: 400, headers, body: JSON.stringify({ error: 'Already registered for this workshop' }) };
        }
        
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Registration failed' }) };
    }
}

async function withdrawRegistration(ticketId, workshopId, headers) {
    if (!ticketId || !workshopId) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: 'Ticket ID and Workshop ID are required' }) };
    }
    
    const upperTicketId = ticketId.toUpperCase();
    
    try {
        // Check if registration exists with conditional delete for atomicity
        await dynamodb.send(new DeleteCommand({
            TableName: REGISTRATIONS_TABLE,
            Key: { ticketId: upperTicketId, workshopId: workshopId },
            // Ensure the registration exists before deletion
            ConditionExpression: 'attribute_exists(ticketId) AND attribute_exists(workshopId)',
            ReturnValues: 'ALL_OLD'
        }));
        
        return { statusCode: 200, headers, body: JSON.stringify({ message: 'Registration withdrawn successfully' }) };
        
    } catch (error) {
        console.error('Error withdrawing registration:', error);
        
        // Handle conditional check failed error specifically
        if (error.name === 'ConditionalCheckFailedException') {
            return { statusCode: 404, headers, body: JSON.stringify({ error: 'Registration not found' }) };
        }
        
        return { statusCode: 500, headers, body: JSON.stringify({ error: 'Failed to withdraw registration' }) };
    }
}